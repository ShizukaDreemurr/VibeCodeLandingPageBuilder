/* ============================================================================
   TEMPLATE — sao chép thành deck.data.js rồi điền các ô đánh số [1]…[11].
   Mở deck.html là thấy ngay. Không sửa deck.html. Xuất PDF: node tools/export.cjs
   Quy ước chữ:  **đậm**   {{nhấn màu gradient}}
   Ảnh: đặt trong assets/ (chụp bằng tools/capture.cjs). Thiếu ảnh thì khung hiện chữ nhắc.
   ẢNH LUÔN LÀ ẢNH ĐIỆN THOẠI DỌC (9:19,5; 390×844@3x = 1170×2532) đặt trong khung điện thoại. Không dùng ảnh ngang/vuông/desktop.
   Tên ảnh theo BẢNG SLOT 01–13 của prompts/14 mục 6: NN-ten-slot-mobile-light.png / NN-ten-slot-mobile-dark.png (01-tong-quan, 02-nhap-lieu, 03-ket-qua, 04-luu-xem-lai, 05..09-tinh-nang-N, 10-ca-sai, 11-ca-bien, 12-gia-dinh, 13-nhan-mo-phong; ví dụ 05-tinh-nang-1-mobile-light.png). Mỗi slide tối đa 3 điện thoại.
   Loại slide cho ảnh dọc: cover · phone (1 máy + 3 chú thích) · phones-2 · phones-3 · phone-steps (luồng 1→2→3) · demo với device:'phone'.
   Mỗi slide có:  speaker: 'Tên'  (người nói, chỉ hiện trong ghi chú, KHÔNG hiện lên slide)  ·  time: '0:40'  (thời lượng gợi ý)  ·
   notes: '...'  (bấm N): Người nói · Mốc giờ · V / T / S = 3 neo · Cue kỹ thuật ("Mời chuyển slide.", vì thành viên không tự bấm slide) · Chuyền mic. Chi tiết: templates/KICH-BAN-DEMO.md.
   Bộ 11 slide cho pitch 10 phút: Diệu Anh 1–3 · Dũng 4–7 · Nguyên 8–11. Đổi tên người nói theo đội. Bản 7 / 5 slide: xem templates/KICH-BAN-DEMO.md mục 6 (Giả định & cách tính = slide 10 / 5 / 4: kit chưa có loại 'assumptions', dùng 'metrics' cho slide đó).
   ============================================================================ */
window.DECK = {
  meta: {
    app: 'TÊN APP',                                    // [1] tên app
    title: 'TÊN APP · Pitch chung kết',
    footer: '**TÊN APP** · Đề X · Bảng B – Kinh tế',             // chân trang mỗi slide
    // Mặc định: giao diện Xclipse (Ice/Navy/Coral). Bảng màu tím cũ: theme: 'classic'. Đổi màu riêng: accent / accent2.
    liveUrl: 'https://xclipsex.github.io/Xclipse-ChungKet/',            // [8] link app đang chạy (tự sinh QR)
    videoUrl: 'https://youtu.be/XXXXXXXXXXX'           // [8] link video demo
  },
  slides: [
    { type: 'cover', time: '0:35', speaker: 'Diệu Anh',
      app: 'TÊN APP',                                  // [1]
      tagline: 'Một câu: làm gì cho ai, nhanh/tốt hơn thế nào.',  // [2] tagline ≤ 15 từ
      de: 'Đề số X', bang: 'Bảng B – Kinh tế', event: 'VIBE-CODING 2026 · Chung kết',  // [3] đề + bảng
      team: 'Xclipse', members: ['Diệu Anh', 'Vũ Trí Dũng', 'Nguyên (nhóm trưởng)'], date: '2026',  // [3]
      image: 'assets/01-tong-quan-mobile-light.png',               // ảnh DỌC 390×844@3x
      notes: 'Người nói: Diệu Anh\nMốc giờ: 00:00–00:35 (cứng 00:40)\nV: {{NHOM_NGUOI_DUNG}} đang mất {{VIEC_TON_THOI_GIAN}}\nT: tên app + 1 câu hứa\nS: {{SO_MUC_TIEU}}\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'problem', time: '0:55', speaker: 'Diệu Anh', eyebrow: 'Vấn đề',
      title: 'Một câu nêu **nỗi đau** của người dùng',
      persona: { name: 'Tên persona', role: 'Vai trò, bối cảnh' },       // [4] persona
      pains: ['Nỗi đau 1', 'Nỗi đau 2', 'Nỗi đau 3'],                    // [4] 2–4 nỗi đau
      scenarioLabel: 'Tình huống điển hình',                              // ghi "thật" chỉ khi đúng là chuyện thật
      scenario: 'Một tình huống cụ thể có **thời điểm, con số, hậu quả**.', // [5]
      stat: { value: 'X phút', label: 'mục tiêu / con số đo được' },
      notes: 'Người nói: Diệu Anh\nMốc giờ: 00:35–01:30 (cứng 01:35)\nV: {{NOI_DAU_CHINH}}\nT: kể 1 tình huống có giờ/số của persona\nS: {{SO_NOI_DAU}}\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'phone', time: '1:00', speaker: 'Diệu Anh', eyebrow: 'Giải pháp',
      title: 'Làm A một lần, ra ngay {{kết quả B}}.',                      // [6] giải pháp một câu
      callouts: [                                                          // 3 chú thích đánh số, ghim trên máy theo y (tuỳ chọn)
        { title: 'Điểm mạnh 1', desc: 'Một dòng giải thích.', y: '20%' },
        { title: 'Điểm mạnh 2', desc: 'Một dòng giải thích.', y: '48%' },
        { title: 'Điểm mạnh 3', desc: 'Một dòng giải thích.', y: '80%' }
      ],
      image: 'assets/03-ket-qua-mobile-light.png',
      notes: 'Người nói: Diệu Anh\nMốc giờ: 01:30–02:30 (cứng 02:35)\nV: giải pháp 1 câu\nT: chỉ vào 3 ghim số trên điện thoại, nêu 1 điểm UI/UX\nS: {{SO_THAO_TAC_HOAN_THANH}}\nCue kỹ thuật: Mời chuyển slide. (nói sau câu chuyền mic)\nChuyền mic: Em xin gửi Dũng đi vào {{TINH_NANG_NOI_BAT}} và làm thử ngay cho mọi người xem.' },

    { type: 'features', time: '0:45', speaker: 'Vũ Trí Dũng', eyebrow: 'Tính năng',
      title: 'Đủ **5 tính năng** của đề',
      items: [                                                             // [7] 5 tính năng (icon: xem danh sách cuối file)
        { icon: 'form', title: 'Tính năng 1', desc: 'Mô tả ≤ 15 từ.' },
        { icon: 'sparkles', title: 'Tính năng 2', desc: 'Mô tả ≤ 15 từ.' },
        { icon: 'layout', title: 'Tính năng 3', desc: 'Mô tả ≤ 15 từ.' },
        { icon: 'users', title: 'Tính năng 4', desc: 'Mô tả ≤ 15 từ.' },
        { icon: 'list', title: 'Tính năng 5', desc: 'Mô tả ≤ 15 từ.' }
      ],
      notes: 'Người nói: Vũ Trí Dũng\nMốc giờ: 02:30–03:15 (cứng 03:20)\nV: 5 tính năng giải đúng đề\nT: nhấn 1 quy tắc nghiệp vụ\nS: {{SO_TINH_NANG}} tính năng chạy thật\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'phone-steps', time: '0:40', speaker: 'Vũ Trí Dũng', eyebrow: 'Luồng sử dụng',
      title: 'Từ A đến B trong **3 bước**',
      steps: [                                                             // 3 ảnh DỌC, thứ tự theo luồng thật
        { image: 'assets/02-nhap-lieu-mobile-light.png', title: 'Bước 1', desc: 'Làm gì' },
        { image: 'assets/03-ket-qua-mobile-light.png', title: 'Bước 2', desc: 'Làm gì' },
        { image: 'assets/04-luu-xem-lai-mobile-light.png', title: 'Bước 3', desc: 'Làm gì' }
      ],
      note: 'Dữ liệu lưu ở đâu / điều cần biết (tuỳ chọn).',
      notes: 'Người nói: Vũ Trí Dũng\nMốc giờ: 03:15–03:55 (cứng 04:00)\nV: người dùng đi qua bao nhiêu bước\nT: chỉ đúng các bước trên slide\nS: {{THOI_GIAN_LUONG_CHINH}} từ đầu đến kết quả\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: Giờ mình xem bản chạy thật.'
    },

    { type: 'demo', time: '1:15', speaker: 'Vũ Trí Dũng', eyebrow: 'Demo trực tiếp',
      title: 'Đang chạy **ngay bây giờ**',
      device: 'phone',                                                     // điện thoại dọc + QR bên cạnh
      image: 'assets/03-ket-qua-mobile-light.png',                            // ảnh DỌC dự phòng khi mất mạng
      iframe: true,                                                        // true = có nút "Chạy trực tiếp" nhúng link live ngay trong khung điện thoại (app phải cho phép iframe)
      caption: 'Kịch bản: **bước 1** → **bước 2** → **bước 3**.',
      notes: 'Người nói: Vũ Trí Dũng\nMốc giờ: 03:55–05:10 (cứng 05:15)\nV: ca bình thường\nT: {{THAO_TAC_1}} → {{THAO_TAC_2}} → {{THAO_TAC_3}}, mỗi thao tác ≤ 25s\nS: kết quả hiện sau {{GIAY_PHAN_HOI}} giây\nCue kỹ thuật: Mời phát video demo. … Mời quay lại slide. → Mời chuyển slide.\nChuyền mic: —' },

    { type: 'phones-3', time: '1:05', speaker: 'Vũ Trí Dũng', eyebrow: 'Demo: ca sai, ca biên, tối',
      title: 'Nhập sai và ca biên: app **xử lý ra sao**',
      phones: [                                                            // 2–3 ảnh DỌC cạnh nhau (dùng 'phones-2' nếu chỉ có 2)
        { image: 'assets/10-ca-sai-mobile-light.png', label: 'Nhập sai', sub: 'Báo lỗi ngay tại ô' },
        { image: 'assets/11-ca-bien-mobile-light.png', label: 'Ca biên', sub: 'Xử lý đúng' },
        { image: 'assets/01-tong-quan-mobile-dark.png', label: 'Giao diện tối', sub: 'Cùng màn hình, chế độ Tối' }
      ],
      points: ['Ca nhập sai → báo lỗi ngay', 'Ca biên → xử lý đúng', 'Chạy ở 360 và 390 px'],
      notes: 'Người nói: Vũ Trí Dũng\nMốc giờ: 05:10–06:15 (cứng 06:20)\nV: ca nhập sai + ca biên + mobile\nT: {{CA_SAI}} báo lỗi ngay; {{CA_BIEN}}; đưa điện thoại ra cho giám khảo thấy giao diện Tối\nS: {{SO_CA_LOI_BAT_DUOC}} ca lỗi bị chặn\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: Phần bên trong chạy thế nào, mình xin nhường Nguyên.' },

    { type: 'ai', time: '1:00', speaker: 'Nguyên', eyebrow: 'AI trong sản phẩm',
      title: 'AI **làm gì**, kiểm soát thế nào',
      realTitle: 'AI thật', real: ['Phần nào gọi AI thật'],               // [9]
      mockTitle: 'Mô phỏng', mock: ['Phần nào là mô phỏng / dữ liệu mẫu (nói thẳng)'],  // [9]
      controlsTitle: 'Kiểm soát', controls: ['Chống bịa', 'Kiểm tra đầu ra', 'Bảo vệ khoá API'],
      pipeline: { steps: [
          { label: 'Prompt', sub: 'dữ kiện từ form' },
          { label: 'Gọi AI', sub: 'model / dán tay', kind: 'key' },
          { label: 'Kiểm tra', sub: 'định dạng, đủ trường', kind: 'key' },
          { label: 'Hiển thị', sub: 'người dùng sửa', kind: 'ok' } ],
        fallbackAt: 2, fallbackLabel: 'lỗi hoặc thiếu',
        fallback: { label: 'Dự phòng', sub: 'bản mô phỏng + báo rõ' } },
      notes: 'Người nói: Nguyên\nMốc giờ: 06:15–07:15 (cứng 07:20)\nV: kiến trúc + AI/proxy gọn\nT: chỉ chỗ key không lộ + nhãn mô phỏng nguyên văn\nS: {{SO_MODULE_HOAC_DIEM_AI}}\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'quality', time: '1:00', speaker: 'Nguyên', eyebrow: 'Kiểm thử',
      title: 'Đủ **3 loại ca**: bình thường, nhập sai, biên',
      rows: [                                                              // [10] ≥ 6 ca; status: 'pass' | 'warn' | 'fail'
        { id: 'TC01', kind: 'Bình thường', case: 'Ca 1', result: 'Kết quả thực tế', status: 'pass' },
        { id: 'TC02', kind: 'Nhập thiếu', case: 'Ca 2', result: 'Kết quả thực tế', status: 'pass' },
        { id: 'TC03', kind: 'Nhập sai', case: 'Ca 3', result: 'Kết quả thực tế', status: 'pass' },
        { id: 'TC04', kind: 'Biên', case: 'Ca 4', result: 'Kết quả thực tế', status: 'pass' },
        { id: 'TC05', kind: 'Biên', case: 'Ca 5', result: 'Còn lỗi nhỏ, đã ghi nhận', status: 'warn', label: 'Đạt, 1 lưu ý' },
        { id: 'TC06', kind: 'Sự cố AI', case: 'Ca 6', result: 'Kết quả thực tế', status: 'pass' }
      ],
      summary: { value: '6/6', label: 'ca đạt, chạy ngày DD/MM' },
      legend: ['Cách kiểm thử (tay / tự động)', 'Lỗi còn lại nói thẳng'],
      notes: 'Người nói: Nguyên\nMốc giờ: 07:15–08:15 (cứng 08:20)\nV: kiểm thử + bảo mật\nT: chỉ 1 ca đã bắt lỗi thật\nS: {{SO_CA_DAT}}/{{TONG_CA}} ca đạt; quét key {{KET_QUA_QUET}}\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'metrics', time: '0:45', speaker: 'Nguyên', eyebrow: 'Tác động',
      title: 'Con số **kiểm chứng được**',
      items: [                                                             // [11] 3–4 con số có nguồn
        { value: 5, suffix: ' phút', label: 'Thời gian từ A đến B', sub: 'Nguồn / cách đo' },
        { value: 100, suffix: '%', label: 'Ca kiểm thử đạt', sub: 'Nguồn / cách đo' },
        { value: 12, label: 'Mẫu / dữ liệu', sub: 'Nguồn / cách đo' }
      ],
      note: 'Phần chưa kiểm chứng (nói thẳng).',
      notes: 'Người nói: Nguyên\nMốc giờ: 08:15–09:00 (cứng 09:05)\nV: giá trị đo được\nT: nói thẳng 1 giới hạn + bước tiếp theo\nS: {{SO_GIA_TRI}}\nCue kỹ thuật: Mời chuyển slide.\nChuyền mic: —' },

    { type: 'thanks', time: '0:45', speaker: 'Nguyên', eyebrow: 'TÊN APP · Đề X · Bảng Y',
      title: 'Cảm ơn!', subtitle: 'Quét mã để dùng thử.', cta: 'Hỏi đáp',
      qrLabel: 'Quét để dùng thử ngay',                                     // url/video lấy từ meta ở trên
      notes: 'Người nói: Nguyên\nMốc giờ: 09:00–09:45 (cứng 09:50)\nV: tổng kết 1 câu\nT: QR + link, mời hỏi đáp\nS: lặp lại {{SO_NHO_NHAT}}\nCue kỹ thuật: — (kỹ thuật viên giữ slide cuối)\nChuyền mic: Cảm ơn ban giám khảo, đội xin nhận câu hỏi.' }
  ]
};
/* Tên icon dùng được: form sparkles wand layout users user qr chart bolt shield clock check x alert globe phone file list
   calendar rocket target heart search edit lock cloud mail star code db arrow image link play money flag bell mic.
   (icon không có trong danh sách sẽ hiện nguyên chữ, ví dụ icon: '1' hoặc '%'.) */
