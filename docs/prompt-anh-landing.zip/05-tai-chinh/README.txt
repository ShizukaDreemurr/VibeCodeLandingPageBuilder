THƯ MỤC 05-tai-chinh

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  finance-hero.webp
2-about.txt  ->  finance-about.webp
3-gift.txt  ->  finance-gift.webp
4-album-1.txt  ->  finance-g1.webp
5-album-2.txt  ->  finance-g2.webp
6-og-image.txt  ->  finance-og.jpg
