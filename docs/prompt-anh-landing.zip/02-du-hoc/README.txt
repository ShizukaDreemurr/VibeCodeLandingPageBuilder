THƯ MỤC 02-du-hoc

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  edu-hero.webp
2-about.txt  ->  edu-about.webp
3-gift.txt  ->  edu-gift.webp
4-album-1.txt  ->  edu-g1.webp
5-album-2.txt  ->  edu-g2.webp
6-og-image.txt  ->  edu-og.jpg
