THƯ MỤC 01-ai-workshop

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  ai-hero.webp
2-about.txt  ->  ai-about.webp
3-gift.txt  ->  ai-gift.webp
4-album-1.txt  ->  ai-g1.webp
5-album-2.txt  ->  ai-g2.webp
6-og-image.txt  ->  ai-og.jpg
