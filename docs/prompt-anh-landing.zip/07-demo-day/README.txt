THƯ MỤC 07-demo-day

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  demoday-hero.webp
2-about.txt  ->  demoday-about.webp
3-gift.txt  ->  demoday-gift.webp
4-album-1.txt  ->  demoday-g1.webp
5-album-2.txt  ->  demoday-g2.webp
6-og-image.txt  ->  demoday-og.jpg
