THƯ MỤC 04-thiep-cuoi

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  wedding-hero.webp
2-about.txt  ->  wedding-about.webp
3-gift.txt  ->  wedding-gift.webp
4-album-1.txt  ->  wedding-g1.webp
5-album-2.txt  ->  wedding-g2.webp
6-og-image.txt  ->  wedding-og.jpg
