THƯ MỤC 06-hackathon

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  hackathon-hero.webp
2-about.txt  ->  hackathon-about.webp
3-gift.txt  ->  hackathon-gift.webp
4-album-1.txt  ->  hackathon-g1.webp
5-album-2.txt  ->  hackathon-g2.webp
6-og-image.txt  ->  hackathon-og.jpg
