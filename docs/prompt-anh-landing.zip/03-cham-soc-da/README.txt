THƯ MỤC 03-cham-soc-da

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

1-hero.txt  ->  beauty-hero.webp
2-about.txt  ->  beauty-about.webp
3-gift.txt  ->  beauty-gift.webp
4-album-1.txt  ->  beauty-g1.webp
5-album-2.txt  ->  beauty-g2.webp
6-og-image.txt  ->  beauty-og.jpg
