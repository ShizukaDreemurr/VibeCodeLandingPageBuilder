THƯ MỤC 08-moc-coffee

Mỗi file .txt = một prompt, dán vào MỘT cuộc trò chuyện Gemini MỚI. Tải ảnh bản lớn nhất, đổi tên đúng như bảng dưới rồi gửi lại.

6-og-image.txt  ->  moc-og.jpg
