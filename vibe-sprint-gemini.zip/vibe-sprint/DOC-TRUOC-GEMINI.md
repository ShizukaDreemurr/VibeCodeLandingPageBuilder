# Bản dành cho Gemini
Gemini không nhận đuôi .cjs/.mjs/.js/.sh/.css/.html nên mọi file code đã được thêm đuôi `.txt`
(ví dụ `tools/bump-version.cjs.txt`). Khi dựng dự án thật, bỏ đuôi `.txt` đi:
  find . -name '*.txt' ! -name 'robots.txt' -exec sh -c 'mv "$1" "${1%.txt}"' _ {} \;
Tải lên nhanh nhất: dùng file `vibe-sprint-ALL-IN-ONE.md` (gộp mọi file chữ vào 1 file).
